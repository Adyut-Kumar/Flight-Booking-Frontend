import { Passenger } from './passenger.model';

describe('Passenger', () => {
  it('should create an instance', () => {
    expect(new Passenger()).toBeTruthy();
  });
});
