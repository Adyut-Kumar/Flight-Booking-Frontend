
  
  export interface Passenger {
    name: string;
    seatNumber: string;
    email: string;
   // age: number;
    gender: 'Male' | 'Female' | 'Other';
  }
  