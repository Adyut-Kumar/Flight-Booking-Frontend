export interface City {
    cityId: number;
    cityCode: string;
    cityName: string;
    state: string;
    airportCharge: number;
    isActive: boolean;
  }
  

  