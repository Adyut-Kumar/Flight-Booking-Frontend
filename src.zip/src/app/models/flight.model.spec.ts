import { Flight } from './flight.model';

describe('Flight', () => {
  it('should create an instance', () => {
    expect(new Flight()).toBeTruthy();
  });
});
